# covid19
Resources for the Udemy Course - Azure Data Factory For Data Engineers - Project on Covid-19
